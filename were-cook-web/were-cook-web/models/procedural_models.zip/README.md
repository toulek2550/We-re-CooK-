# We're CooK? — 3D models (ไม่รวมตัวละคร)

## procedural/ — โมเดลที่ปั้นด้วยโค้ดสำหรับเกมนี้ (74 ชิ้น)
- `ingredients/` วัตถุดิบและอาหาร · `kitchen_tools/` ครก อั้งโล่ ซึ้ง หม้อทอด กระทะ เตาอบ ฯลฯ · `seasoning_bottles/` ขวดปรุง
- แต่ละชิ้นมี 2 แบบ: `glb/` (glTF 2.0 ไฟล์เดียว) และ `obj/` (OBJ + MTL)
- low-poly สีเรียบต่อชิ้นส่วน (ไม่มี texture) · หน่วย ~1 = 1 ช่องเคาน์เตอร์ KayKit · แกน Y ชี้ขึ้น
- สถานะสุก/ไหม้ในเกมใช้การย้อมสีตอนเรนเดอร์ (ดู `tools/render/spec.py`) ไฟล์นี้เป็นสีดิบ ยกเว้นชิ้นที่มีรูปทรงแยก เช่น egg_fried / egg_burnt / shrimp / shrimp_raw
- ต้นฉบับ: `tools/render/models.js` · สัญญาอนุญาต: CC0 (ทำขึ้นเองสำหรับโปรเจกต์)

## kaykit_used/ — โมเดล KayKit Restaurant Bits ที่เกมใช้ (44 ชิ้น)
- glTF + .bin + texture atlas เดียว `restaurantbits_texture.png`
- โดย Kay Lousberg · CC0 (ดู `KayKit_License.txt`) · แพ็กเต็ม 144 ชิ้นอยู่ใน zip ที่คุณส่งมา
